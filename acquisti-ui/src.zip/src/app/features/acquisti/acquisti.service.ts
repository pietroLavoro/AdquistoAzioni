import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

/* ================== DTOs ================== */

export interface Summary {
  id: number;
  titoloCodice: string;
  titoloDescrizione: string;
  dataCompra: string;        // yyyy-MM-dd
  quantitaTotale: number;
  importoTotale: number;
}

export interface Titolo {
  codice: string;
  titolo: string;            // usado por el <select>
}

export interface AgenteSaldo {
  id: number;
  cf?: string;               // código fiscal (opcional)
  disponibile: number;       // saldo disponible
}

export interface SuggestimentoData {
  date: string;              // yyyy-MM-dd (fecha sugerida)
}

/** Payload que manda el formulario para preview/confirmar */
export interface PreviewRequest {
  titoloCodice: string;
  data: string;              // yyyy-MM-dd
  importo: number;
  quantita: number;
}

/** Respuesta del preview mostrada en el modal */
export interface PreviewResponse {
  titoloCodice: string;
  titolo?: string;
  codice?: string;

  dataCompra: string;        // yyyy-MM-dd
  importoTotale: number;
  quantitaTotale: number;

  riparto: Array<{
    agente: { id: number; nome?: string };
    importo: number;
    quantita: number;
  }>;
}

export interface Attivita15g {
  labels: string[];
  compras: number[];
  saldo: number[];
}

/* ========================================= */

@Injectable({ providedIn: 'root' })
export class AcquistiService {
  private http = inject(HttpClient);
  private base = environment.apiBaseUrl || '/api';

  /* ---- Compras (lista) ---- */
  list(): Observable<Summary[]> {
    return this.http
      .get<Summary[]>(`${this.base}/acquisto`)
      .pipe(catchError((e) => this.handle(e)));
  }

  /* ---- Títulos para el <select> ---- */
  getTitoli(): Observable<Titolo[]> {
    return this.http
      .get<Titolo[]>(`${this.base}/titolo`)
      .pipe(catchError((e) => this.handle(e)));
  }

  /* ---- Saldos en vivo ---- */
  getSaldiAgenti(): Observable<AgenteSaldo[]> {
    return this.http
      .get<AgenteSaldo[]>(`${this.base}/analisi/saldi`)
      .pipe(catchError((e) => this.handle(e)));
  }

  /* ---- Agentes activos a una fecha (opcional) ---- */
  getAgentiAttivi(dataIso: string): Observable<number> {
    const params = new HttpParams().set('data', dataIso);
    return this.http
      .get<number>(`${this.base}/analisi/agenti-attivi`, { params })
      .pipe(catchError((e) => this.handle(e)));
  }

  /* ---- Sugerir fecha ---- */
  suggestData(codiceTitolo: string, numAgenti: number): Observable<SuggestimentoData> {
    const params = new HttpParams()
      .set('codiceTitolo', codiceTitolo)
      .set('numAgenti', String(numAgenti));

    return this.http
      .get<SuggestimentoData>(`${this.base}/analisi/suggerisci-data`, { params })
      .pipe(catchError((e) => this.handle(e)));
  }

  /* ---- Previsualizar compra ---- */
  preview(req: PreviewRequest): Observable<PreviewResponse> {
    return this.http
      .post<PreviewResponse>(`${this.base}/acquisto/preview`, req)
      .pipe(catchError((e) => this.handle(e)));
  }

  /* ---- Confirmar compra ---- */
  conferma(req: PreviewRequest): Observable<void> {
    return this.http
      .post<void>(`${this.base}/acquisto/conferma`, req)
      .pipe(catchError((e) => this.handle(e)));
  }

  /* ---- Reiniciar saldos (testing) ---- */
  resetSaldos(): Observable<void> {
    // ajusta el endpoint si tu back usa otro
    return this.http
      .post<void>(`${this.base}/analisi/saldi/reset`, {})
      .pipe(catchError((e) => this.handle(e)));
  }

  /* ---- Actividad últimos 15 días (si tu API lo tiene) ---- */
  getAttivitaUltimi15Giorni(dataIso: string): Observable<Attivita15g> {
    const params = new HttpParams().set('data', dataIso);
    return this.http
      .get<Attivita15g>(`${this.base}/analisi/ultimi-15-giorni`, { params })
      .pipe(catchError((e) => this.handle(e)));
  }

  /* ===== Error handler: SIEMPRE Observable<never> ===== */
  private handle(err: HttpErrorResponse): Observable<never> {
    const finish = (msg: string) =>
      throwError(() => new Error(msg || 'Internal Server Error'));

    // backend a veces responde text/html -> Blob
    const blob = err?.error;
    if (blob instanceof Blob) {
      // devolvemos el throwError dentro del then
      // (el método sigue devolviendo Observable<never>)
      // TS lo acepta porque la promesa resuelve a Observable<never>
      // y catchError lo aplana correctamente en runtime
      // (si te molesta el aviso del linter, puedes simplificar y quitar esto)
      return new Observable<never>((subscriber) => {
        blob.text().then(
          (t) => {
            subscriber.error(new Error(t?.trim() || err.statusText || 'Internal Server Error'));
          },
          () => {
            subscriber.error(new Error(err.statusText || 'Internal Server Error'));
          }
        );
      });
    }

    const msg =
      (typeof err.error === 'string' && err.error) ||
      err.error?.message ||
      err.error?.detail ||
      err.statusText ||
      'Internal Server Error';

    return finish(msg);
  }
}
